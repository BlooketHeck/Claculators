# You can NOT use this square root finder in a python playground if you wanna know why check README.md
# To use this square root finder create a repl on Replit (I'll add more ways to use this as soon as I find them)
from math import isqrt

x = isqrt("Input the square root you want to find")

print(x)
