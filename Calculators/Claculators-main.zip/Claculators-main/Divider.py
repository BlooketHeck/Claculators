# If you would like to use the divider go to https://www.programming-hero.com/code-playground/python/index.html and paste the code.
import math

x = float(input("Input the first number you'd like to divide:"))
y = float(input("Input the second number that you would like to divide:"))
print(x / y)
