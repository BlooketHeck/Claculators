# If you would like to use the adder go to https://www.programming-hero.com/code-playground/python/index.html and paste the code. For num 3-5 leave 0 if blank.
import math

num1 = float(input("Input the first number you'd like to add:"))
num2 = float(input("Input the second number that you would like to add:"))
num3 = float(input("Input the third number that you would like to add:"))
num4 = float(input("Input the forth number that you would like to add:"))
num5 = float(input("Input the fith number that you would like to add:"))
print(num1 + num2 + num3 + num4 + num5)
