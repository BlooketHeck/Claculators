# If you would like to use the multiplier go to https://www.programming-hero.com/code-playground/python/index.html and paste the code.
import math

x = float(input("Input the first number you'd like to multiply:"))
y = float(input("Input the second number that you would like to multiply:"))
print(x * y)
